#!/bin/bash
set -e
#set -x

source setup/install_functions.sh


check_dependencies
check_repository_state

create_env_file_and_load_it

download_save_and_load_image $IMAGE_T51JENKINS "IMAGE_T51JENKINS"
download_save_and_load_image $IMAGE_JENKINS "IMAGE_JENKINS"
download_save_and_load_image $IMAGE_GITEA "IMAGE_GITEA"
download_save_and_load_image $IMAGE_JAVA "IMAGE_JAVA"
download_save_and_load_image $IMAGE_NODE "IMAGE_NODE"
download_save_and_load_image $IMAGE_NGINX "IMAGE_NGINX"
download_save_and_load_image $IMAGE_HTTPD "IMAGE_HTTPD"
download_save_and_load_image $IMAGE_DB "IMAGE_DB"
download_save_and_load_image $IMAGE_T51DB_UTILS "IMAGE_T51DB_UTILS"
download_save_and_load_image $IMAGE_DB_MIG_BASE "IMAGE_DB_MIG_BASE"
download_save_and_load_image $IMAGE_DB_MIG "IMAGE_DB_MIG"
download_save_and_load_image $IMAGE_REVERSE_PROXY "IMAGE_REVERSE_PROXY"
download_save_and_load_image $IMAGE_ACME_COMPANION "IMAGE_ACME_COMPANION"
download_save_and_load_image $IMAGE_MVN "IMAGE_MVN"
download_save_and_load_image $IMAGE_NEXUS "IMAGE_NEXUS"
download_save_and_load_image $IMAGE_CURL "IMAGE_CURL"

create_ssh_keys
# root access required to add entries to ~/.ssh/config file.
add_project_ssh_public_key_to_docker_host_ssh_config

create_registry_auth

# root access required to add entries to /etc/hosts file
add_domain_to_hosts_file $MY_DOMAIN
add_domain_to_hosts_file api.$MY_DOMAIN
add_domain_to_hosts_file gitea.$MY_DOMAIN
add_domain_to_hosts_file jenkins.$MY_DOMAIN
add_domain_to_hosts_file nexus.$MY_DOMAIN

docker compose up -d reverse-proxy
start_and_check_health_devops_service gitea
start_and_check_health_devops_service jenkins
start_and_check_health_devops_service nexus


clone_repository $BACK_REPO ./app/back/source
clone_repository $DB_MIG_REPO ./app/db/source
clone_repository $FRONT_REPO ./app/front/source

start_app_database_service_and_install_schema

start_app_backend_service

start_app_frontend_service

echo "Installation completed successfully."


# example of running the install.sh script:
# bash ./install.sh <<EOF
# test
# example1-test.com
# myUser
# myPass123p
# myPass123p
# EOF